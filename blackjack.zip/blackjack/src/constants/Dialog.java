package constants;

public abstract class Dialog {

    public static final String hello = "hello";
    public static final String nameCollision = "nameCollision";
    public static final String confirmStand = "confirmStand";
    public static final String confirmHit = "confirmHit";
    public static final String confirmSplit = "confirmSplit";
    public static final String confirmDoubleDown = "confirmDoubleDown";
    public static final String actionDenied = "actionDenied";
    public static final String notAffordable = "notAffordable";
    public static final String dealerHit = "dealerHit";
    public static final String roundEnd = "roundEnd";
    public static final String playerBroke = "playerBroke";
    public static final String farewell = "farewell";
    public static final String welcomeUnknown = "welcomeUnknown";
    public static final String welcomeLoser = "welcomeLoser";
    public static final String welcomeWinner = "welcomeWinner";
    public static final String address = "address";
    public static final String next = "next";
    public static final String insufficientBalance = "insufficientBalance";
    public static final String noBetPresent = "noBetPresent";
    public static final String payday = "payday";
    public static final String refund = "refund";
    public static final String loss = "loss";
    public static final String mainHand = "mainHand";
    public static final String secondHand = "secondHand";
    public static final String otherHand = "otherHand";
    public static final String dealerHand = "dealerHand";
    public static final String dealerHandUpdated = "dealerHandUpdated";
    public static final String dealerBlackjack = "dealerBlackjack";
    public static final String playerBusted = "playerBusted";
    public static final String dealerBusted = "dealerBusted";
    public static final String playerWins = "playerWins";
    public static final String tie = "tie";
    public static final String playerLoses = "playerLoses";
    public static final String name = "name";
    public static final String bringFriends = "bringFriends";
    public static final String anyoneJoin = "anyoneJoin";
    public static final String betAmount = "betAmount";
    public static final String sideBet = "sideBet";
    public static final String sideBetName = "sideBetName";
    public static final String action = "action";
    public static final String specifyBoolean = "specifyBoolean";
    public static final String specifyInt = "specifyInt";
    public static final String specifyAction = "specifyAction";
    public static final String repeatQuestion = "repeatQuestion";

}
