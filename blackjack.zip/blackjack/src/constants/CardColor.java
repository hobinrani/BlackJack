package constants;

public enum CardColor {
    hearts, diamonds, clubs, spades;
}
