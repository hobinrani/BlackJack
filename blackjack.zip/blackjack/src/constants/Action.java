package constants;

public enum Action {
    stand, hit, doubleDown, split
}
