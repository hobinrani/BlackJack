package main;

import constants.Card;
import helpers.FileIO;
import model.AutoRestockDeck;
import model.Game;
import cli.ChatBot;
import model.Player;
import translation.SynonymTranslator;

import java.util.Scanner;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

public class Application {

    private static Application instance; // singleton

    private static final Scanner sc = new Scanner(System.in);
    private static Supplier<String> in = sc::nextLine;
    private static Consumer<String> out = System.out::print;
    private static Supplier<Card> deck = new AutoRestockDeck();
    private static Function<String, Player> playerLoader = FileIO::loadPlayer;
    private static BiConsumer<String, Player> playerStore = FileIO::savePlayer;
    private static SynonymTranslator synonymTranslator;

    /**
     * strategy pattern to allow testability
     * @param in supplier of user input
     */
    public static void useInputSupplier(Supplier<String> in) {
        Application.in = in;
        if (instance != null) instance.game.useInputSupplier(in);
    }

    /**
     * strategy pattern to allow testability.
     * @param out consumer of application output
     */
    public static void useOutputConsumer(Consumer<String> out) {
        Application.out = out;
        if (instance != null) instance.game.useOutputConsumer(out);
    }

    /**
     * strategy pattern to allow testability.
     * @param deck supplier of cards
     */
    public static void useCardSupplier(Supplier<Card> deck) {
        Application.deck = deck;
        if (instance != null) instance.game.useCardSupplier(deck);
    }

    /**
     * strategy pattern to allow testability.
     * @param playerLoader strategy to load a player
     * @param playerStore strategy to store a player
     */
    public static void usePlayerLoader(Function<String, Player> playerLoader, BiConsumer<String, Player> playerStore) {
        Application.playerLoader = playerLoader;
        Application.playerStore = playerStore;
        if (instance != null) instance.game.usePlayerLoader(playerLoader, playerStore);
    }

    /**
     * changes the synonym translator of the game
     */
    public static void useSynonymTranslator(SynonymTranslator synonymTranslator) {
        Application.synonymTranslator = synonymTranslator;
        if (instance != null) instance.game.useSynonymTranslator(synonymTranslator);
    }

    public static void main(String[] args) {
        if (instance != null) instance.game.dismiss();
        instance = new Application(new Game(new ChatBot(synonymTranslator, in, out), deck, playerLoader, playerStore));
        instance.game.run();
    }

    private final Game game;

    private Application(Game game) {
        this.game = game;
    }
}
