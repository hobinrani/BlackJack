package translation;

import java.util.HashMap;

public class IntTranslator extends HashMap<String, Integer> {

    public static final int MAXIMUM_VALUE = 1000000;

    public IntTranslator() {
        for (int i = 0; i <= MAXIMUM_VALUE; i++) put(""+i, i);
    }
}
