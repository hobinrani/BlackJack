package translation;

import java.util.HashMap;

public class BooleanTranslator extends HashMap<String, Boolean> {
    public BooleanTranslator() {
        put("true", true);
        put("+", true);
        put("1", true);
        put("y", true);
        put("yes", true);
        put("ja", true);
        put("oui", true);
        put("si", true);
        put("yeah", true);
        put("sure", true);
        put("of course", true);
        put("naturally", true);
        put("obviously", true);

        put("false", false);
        put("-", false);
        put("0", false);
        put("n", false);
        put("no", false);
        put("nei", false);
        put("nein", false);
        put("non", false);
        put("of course not", false);
        put("doubtfully", false);
    }
}
