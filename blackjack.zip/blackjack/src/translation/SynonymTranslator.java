package translation;

import constants.Dialog;

import java.io.Serializable;
import java.util.*;

public class SynonymTranslator extends HashMap<String, List<String>> {

    protected static final long serialVersionUID = 42L;
    
    private transient Random random;
    
    public SynonymTranslator() {
        put("synonymTranslatorFilename", Collections.singletonList("James"));

        put(Dialog.hello, new ArrayList<>(Arrays.asList(
                "Good evening! My name is James and I will be your host tonight.\n",
                "Greetings! Let me introduce myself. My name is James and I will be your dealer.\n"
        )));
        put(Dialog.nameCollision, new ArrayList<>(Arrays.asList(
                "No, the two of you cannot have the same name. ",
                "I'm sorry I get confused when two persons are called the same. "
        )));
        put(Dialog.confirmStand, new ArrayList<>(Arrays.asList(
                "Looks promising!\n",
                "You're right, better not push your luck.\n",
                "Better be safe than sorry.\n",
                "I'd keep that hand as well!\n",
                "Good call.\n"
        )));
        put(Dialog.confirmHit, new ArrayList<>(Arrays.asList(
                "Very well. "
        )));
        put(Dialog.confirmSplit, new ArrayList<>(Arrays.asList(
                "Very well. "
        )));
        put(Dialog.confirmDoubleDown, new ArrayList<>(Arrays.asList(
                "Very well. "
        )));
        put(Dialog.actionDenied, new ArrayList<>(Arrays.asList(
                "I'm afraid that's not possible here.\n",
                "If only that option was available at this point.\n",
                "Alas, your current situation doesn't allow that.\n"
        )));
        put(Dialog.notAffordable, new ArrayList<>(Arrays.asList(
                "I'm afraid you can't afford that.\n",
                "It's a shame, but your purse won't allow that.\n"
        )));
        put(Dialog.dealerHit, new ArrayList<>(Arrays.asList(
                "Let me draw a card...\n",
                "I'm not quite happy with that yet.\n",
                "Let's take the risk and hit the deck.\n",
                "I will draw a card...\n"
        )));
        put(Dialog.roundEnd, new ArrayList<>(Arrays.asList(
                "What a round! I'm looking forward to the next one!\n\n",
                "I love this game! Here comes the next round...\n\n",
                "That was exciting! Let's start another round!\n\n"
        )));
        put(Dialog.playerBroke, new ArrayList<>(Arrays.asList(
                "What a shame, you're all out of chips! That means farewell my friend, but please come back soon!\n",
                "I'm afraid you already spent all your money. Goodbye and wish you more luck in the future!\n"
        )));
        put(Dialog.farewell, new ArrayList<>(Arrays.asList(
                "It was fun playing with you! see you later!\n"
        )));
        put(Dialog.welcomeUnknown, new ArrayList<>(Arrays.asList(
                "Nice to meet you, %s! I think we never had the pleasure. ",
                "What a pretty name, %s! I think I never heard it before. ",
                "Well met, %s! I suppose it's your first time in Group 21's Black Jack casino. "
        )));
        put(Dialog.welcomeLoser, new ArrayList<>(Arrays.asList(
                "Welcome back, %s! Good to see that you recovered from your last gambling session. "
        )));
        put(Dialog.welcomeWinner, new ArrayList<>(Arrays.asList(
                "Welcome back, %s! And damn, look at that rolex of yours! "
        )));
        put(Dialog.address, new ArrayList<>(Arrays.asList(
                "%s, "
        )));
        put(Dialog.next, new ArrayList<>(Arrays.asList(
                "Alright %s, ",
                "Now to you %s, ",
                "My friend %s, ",
                "%s, "
        )));
        put(Dialog.insufficientBalance, new ArrayList<>(Arrays.asList(
                "I'm afraid you only have %d$ left. ",
                "I'm afraid you can only spare %d$. "
        )));
        put(Dialog.noBetPresent, new ArrayList<>(Arrays.asList(
                "I can't find the person you're looking for. Maybe they are yet to join, or decided to skip this round. I can't tell the difference unfortunately.\n",
                "You must bet on someone who actually participates in this round. "
        )));
        put(Dialog.payday, new ArrayList<>(Arrays.asList(
                "your bet paid off: %d$!\n",
                "your bet was worth it: %d$!\n",
                "here's %d$ doubled for you!\n",
                "you get back your bet and gain another %d$!\n"
        )));
        put(Dialog.refund, new ArrayList<>(Arrays.asList(
                "have your %d$ back.\n",
                "next time your %d$ will double hopefully.\n",
                "at least you didn't lose your %d$.\n"
        )));
        put(Dialog.mainHand, new ArrayList<>(Arrays.asList(
                "Your main hand is: %s ",
                "Your hand consists of: %s ",
                "You have: %s "
        )));
        put(Dialog.secondHand, new ArrayList<>(Arrays.asList(
                "Your second hand is: %s ",
                "Here's your split hand: %s "
        )));
        put(Dialog.otherHand, new ArrayList<>(Arrays.asList(
                "Your next hand is: %s ",
                "Your other hand is: %s "
        )));
        put(Dialog.dealerHand, new ArrayList<>(Arrays.asList(
                "My own hand is: %s\n",
                "I myself have: %s\n"
        )));
        put(Dialog.dealerHandUpdated, new ArrayList<>(Arrays.asList(
                "I now have: %s\n",
                "Now my hand consists of: %s\n"
        )));
        put(Dialog.dealerBlackjack, new ArrayList<>(Arrays.asList(
                "Praise the lord, I have a Black Jack: %s That is, I get to keep all your bets.\n"
        )));
        put(Dialog.playerBusted, new ArrayList<>(Arrays.asList(
                "Oh no, you busted: %s\n",
                "What a pity, you broke the limit: %s\n",
                "Tough luck, your hand got beyond 21: %s\n"
        )));
        put(Dialog.dealerBusted, new ArrayList<>(Arrays.asList(
                "Darn it, I busted: %s\n",
                "Oh flip! Now I got too high: %s\n"
        )));
        put(Dialog.playerWins, new ArrayList<>(Arrays.asList(
                "your hand wins: %s Congratulations!\n"
        )));
        put(Dialog.tie, new ArrayList<>(Arrays.asList(
                "your hand ties: %s let me refund...\n"
        )));
        put(Dialog.playerLoses, new ArrayList<>(Arrays.asList(
                "your hand loses: %s I'm sorry.\n"
        )));
        put(Dialog.name, new ArrayList<>(Arrays.asList(
                "What's your name?\n",
                "Will you tell me your name?\n",
                "May I ask for your name?\n",
                "How may I address you?\n"
        )));
        put(Dialog.bringFriends, new ArrayList<>(Arrays.asList(
                "Did you bring any friends?\n",
                "Did you bring company?\n"
        )));
        put(Dialog.anyoneJoin, new ArrayList<>(Arrays.asList(
                "Anyone else who would like to play?\n",
                "We still have space at the table. Does anyone else want to join?\n"
        )));
        put(Dialog.betAmount, new ArrayList<>(Arrays.asList(
                "How much would you like to bet?\n",
                "How much are you willing to risk?\n",
                "How many chips will you put at stake?\n",
                "How much will you wager?\n"
        )));
        put(Dialog.sideBet, new ArrayList<>(Arrays.asList(
                "Would you like to bet on another hand?\n",
                "Can I persuade you to put a wager on your friend's hand?\n",
                "Do you trust your friends enough to bet money on them?\n",
                "What about a little side bet?\n"
        )));
        put(Dialog.sideBetName, new ArrayList<>(Arrays.asList(
                "And who deserves the honor?\n",
                "Who do you want to put your trust in?\n",
                "Which player would you like to wager on?\n"
        )));
        put(Dialog.action, new ArrayList<>(Arrays.asList(
                "What would you like to do?\n",
                "What will you do with that?\n",
                "Hit or stand?\n"
        )));
        put(Dialog.specifyBoolean, new ArrayList<>(Arrays.asList(
                "does that mean yes or no?\n"
        )));
        put(Dialog.specifyInt, new ArrayList<>(Arrays.asList(
                "what number does that refer to?\n"
        )));
        put(Dialog.specifyAction, new ArrayList<>(Arrays.asList(
                "does that mean stand, hit, double down or split?\n"
        )));
        put(Dialog.repeatQuestion, new ArrayList<>(Arrays.asList(
                "Let me repeat the original question: %s"
        )));

        
        
        
    }
    
    public String translate(String key) {
        if (random == null) random = new Random();
        List<String> options = super.get(key);
        if (options.isEmpty()) throw new IllegalStateException();
        return options.get(random.nextInt(options.size()));
    }
}
