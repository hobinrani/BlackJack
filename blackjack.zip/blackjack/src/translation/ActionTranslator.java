package translation;

import constants.Action;

import java.util.HashMap;

public class ActionTranslator extends HashMap<String, Action> {
    public ActionTranslator() {

        put("hit", Action.hit);
        put("draw", Action.hit);
        put("card", Action.hit);
        put("draw card", Action.hit);
        put("draw a card", Action.hit);
        put("one more", Action.hit);
        put("give me a card", Action.hit);
        put("draw from deck", Action.hit);

        put("stand", Action.stand);
        put("okay", Action.stand);
        put("ok", Action.stand);
        put("keep", Action.stand);
        put("confirm", Action.stand);
        put("nothing", Action.stand);
        put("do nothing", Action.stand);

        put("split", Action.split);

        put("doubleDown", Action.doubleDown);
        put("double", Action.doubleDown);
        put("double down", Action.doubleDown);
    }
}
