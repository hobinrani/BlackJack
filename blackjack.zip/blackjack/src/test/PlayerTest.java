package test;

import model.Game;
import model.Player;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Random;

import static org.junit.jupiter.api.Assertions.*;

class PlayerTest {

    Random random;
    String name;
    Player unitUnderTest;

    @BeforeEach
    void setUp() {
        random = new Random();
        name = "player#"+random.nextInt(10000);
        unitUnderTest = new Player(name);
    }

    @Test
    void getName() {
        assertEquals(name, unitUnderTest.getName());
    }

    @Test
    void getBalance() {
        Assertions.assertEquals(Game.DEFAULT_STARTING_BALANCE, unitUnderTest.getBalance());
        for (int i = Game.DEFAULT_STARTING_BALANCE -1; i >= 0; i--) {
            unitUnderTest.pay(1);
            assertEquals(i, unitUnderTest.getBalance());
        }
        for (int i = 10; i < 1000; i += 10) {
            unitUnderTest.gain(10);
            assertEquals(i, unitUnderTest.getBalance());
        }
        for (int i = 0; i < 100; i++) {
            int r = random.nextInt(1000);
            // set random balance
            unitUnderTest.pay(unitUnderTest.getBalance());
            unitUnderTest.gain(r);
            assertEquals(r, unitUnderTest.getBalance());
        }
    }

    @Test
    void resetBalance() {
        unitUnderTest.gain(100000);
        unitUnderTest.resetBalance();
        assertEquals(Game.DEFAULT_STARTING_BALANCE, unitUnderTest.getBalance());

        unitUnderTest.pay(unitUnderTest.getBalance());
        unitUnderTest.resetBalance();
        assertEquals(Game.DEFAULT_STARTING_BALANCE, unitUnderTest.getBalance());
    }

    @Test
    void canAfford() {
        for (int i = 0; i < 100; i++) {
            // set random balance
            unitUnderTest.pay(unitUnderTest.getBalance());
            unitUnderTest.gain(random.nextInt(1000));

            int amount = random.nextInt(unitUnderTest.getBalance() *2);
            if (amount <= unitUnderTest.getBalance()) {
                assertTrue(unitUnderTest.canAfford(amount));
            } else {
                assertFalse(unitUnderTest.canAfford(amount));
            }
        }
    }

    @Test
    void pay() {
        for (int i = 0; i < 100; i++) {
            // set balance to 1000
            unitUnderTest.pay(unitUnderTest.getBalance());
            unitUnderTest.gain(1000);

            int r = random.nextInt(1000);
            int result = unitUnderTest.pay(r);
            assertEquals(r, result);
            assertEquals(1000-r, unitUnderTest.getBalance());
        }

        unitUnderTest.pay(unitUnderTest.getBalance());
        unitUnderTest.gain(100);

        for (int i = 0; i < 100; i++) {
            int negative = -random.nextInt(100) -1;
            assertThrows(IllegalArgumentException.class, () -> unitUnderTest.pay(negative));
        }
        for (int i = 0; i < 100; i++) {
            int tooMuch = random.nextInt(100) + 101;
            assertThrows(IllegalStateException.class, () -> unitUnderTest.pay(tooMuch));
        }
    }

    @Test
    void gain() {
        unitUnderTest.pay(unitUnderTest.getBalance());
        int balanceCalculated = 0;
        for (int i = 0; i < 100; i++) {
            assertEquals(balanceCalculated, unitUnderTest.getBalance());
            int r = random.nextInt(100);
            unitUnderTest.gain(r);
            balanceCalculated += r;
        }
        for (int i = 0; i < 100; i++) {
            int negative = -random.nextInt(100) -1;
            assertThrows(IllegalArgumentException.class, () -> unitUnderTest.gain(negative));
        }

    }
}