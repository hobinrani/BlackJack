package test;

import constants.Card;
import constants.CardValue;
import model.Hand;
import model.Player;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Collections;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class HandTest {

    Random random = new Random();
    Player player = new Player("example");
    Hand unitUnderTest;

    @BeforeEach
    void setUp() {
        unitUnderTest = new Hand(player, 1);
    }

    @Test
    void isBusted() {
        assertFalse(unitUnderTest.isBusted());

        unitUnderTest.draw(Card.eight_of_clubs); // 8
        assertFalse(unitUnderTest.isBusted());
        unitUnderTest.draw(Card.eight_of_spades); // 16
        assertFalse(unitUnderTest.isBusted());
        unitUnderTest.draw(Card.eight_of_diamonds); // 24
        assertTrue(unitUnderTest.isBusted());

        unitUnderTest = new Hand(player, 1);
        unitUnderTest.draw(Card.king_of_clubs); // 10
        assertFalse(unitUnderTest.isBusted());
        unitUnderTest.draw(Card.queen_of_clubs); // 20
        assertFalse(unitUnderTest.isBusted());
        unitUnderTest.draw(Card.ace_of_hearts); // 21|31
        assertFalse(unitUnderTest.isBusted());
        unitUnderTest.draw(Card.ace_of_spades); // 22|32|42
        assertTrue(unitUnderTest.isBusted());

        unitUnderTest = new Hand(player, 1, Card.ace_of_diamonds, Card.ace_of_clubs); // 2|12|22
        assertFalse(unitUnderTest.isBusted());
        unitUnderTest.draw(Card.two_of_hearts); // 4|14|24
        assertFalse(unitUnderTest.isBusted());
        unitUnderTest.draw(Card.three_of_spades); // 7|17|27
        assertFalse(unitUnderTest.isBusted());
        unitUnderTest.draw(Card.four_of_diamonds); // 11|21|31
        assertFalse(unitUnderTest.isBusted());
        unitUnderTest.draw(Card.jack_of_spades); // 21|31|41
        assertFalse(unitUnderTest.isBusted());
        unitUnderTest.draw(Card.ace_of_spades); // 22|32|42|52
        assertTrue(unitUnderTest.isBusted());

    }

    @Test
    void value() {
    }

    @Test
    void ambiguousValues() {
        assertEquals(Collections.singleton(0), unitUnderTest.ambiguousValues());

        unitUnderTest.draw(Card.eight_of_clubs); // 8
        assertEquals(Collections.singleton(8), unitUnderTest.ambiguousValues());
        unitUnderTest.draw(Card.eight_of_spades); // 16
        assertEquals(Collections.singleton(16), unitUnderTest.ambiguousValues());
        unitUnderTest.draw(Card.eight_of_diamonds); // 24
        assertEquals(Collections.singleton(24), unitUnderTest.ambiguousValues());

        unitUnderTest = new Hand(player, 1);
        unitUnderTest.draw(Card.king_of_clubs); // 10
        assertEquals(Collections.singleton(10), unitUnderTest.ambiguousValues());
        unitUnderTest.draw(Card.queen_of_clubs); // 20
        assertEquals(Collections.singleton(20), unitUnderTest.ambiguousValues());
        unitUnderTest.draw(Card.ace_of_hearts); // 21|31
        assertEquals(Set.of(21,31), unitUnderTest.ambiguousValues());
        unitUnderTest.draw(Card.ace_of_spades); // 22|32|42
        assertEquals(Set.of(22,32,42), unitUnderTest.ambiguousValues());

        unitUnderTest = new Hand(player, 1, Card.ace_of_diamonds, Card.ace_of_clubs); // 2|12|22
        assertEquals(Set.of(2,12,22), unitUnderTest.ambiguousValues());
        unitUnderTest.draw(Card.two_of_hearts); // 4|14|24
        assertEquals(Set.of(4,14,24), unitUnderTest.ambiguousValues());
        unitUnderTest.draw(Card.three_of_spades); // 7|17|27
        assertEquals(Set.of(7,17,27), unitUnderTest.ambiguousValues());
        unitUnderTest.draw(Card.four_of_diamonds); // 11|21|31
        assertEquals(Set.of(11,21,31), unitUnderTest.ambiguousValues());
        unitUnderTest.draw(Card.jack_of_spades); // 21|31|41
        assertEquals(Set.of(21,31,41), unitUnderTest.ambiguousValues());
        unitUnderTest.draw(Card.ace_of_spades); // 22|32|42|52
        assertEquals(Set.of(22,32,42,52), unitUnderTest.ambiguousValues());
    }

    @Test
    void isAmbiguous() {
        unitUnderTest = new Hand(player, 1, Card.nine_of_diamonds);
        assertFalse(unitUnderTest.isAmbiguous());
        unitUnderTest = new Hand(player, 1, Card.two_of_hearts, Card.three_of_hearts);
        assertFalse(unitUnderTest.isAmbiguous());
        unitUnderTest = new Hand(player, 1, Card.king_of_clubs, Card.seven_of_diamonds);
        assertFalse(unitUnderTest.isAmbiguous());
        unitUnderTest = new Hand(player, 1, Card.six_of_spades, Card.three_of_hearts, Card.jack_of_spades);
        assertFalse(unitUnderTest.isAmbiguous());
        unitUnderTest = new Hand(player, 1, Card.ace_of_spades, Card.three_of_hearts);
        assertTrue(unitUnderTest.isAmbiguous());
        unitUnderTest = new Hand(player, 1, Card.ace_of_clubs);
        assertTrue(unitUnderTest.isAmbiguous());
        unitUnderTest.draw(Card.ace_of_spades);
        assertTrue(unitUnderTest.isAmbiguous());
        unitUnderTest.draw(Card.ace_of_spades);
        assertTrue(unitUnderTest.isAmbiguous());
        unitUnderTest.draw(Card.ace_of_spades);
        assertTrue(unitUnderTest.isAmbiguous());
        unitUnderTest.draw(Card.queen_of_clubs);
        assertTrue(unitUnderTest.isAmbiguous());
        unitUnderTest.draw(Card.five_of_hearts);
        assertTrue(unitUnderTest.isAmbiguous());
    }

    @Test
    void isBlackJack() {
        unitUnderTest = new Hand(player, 1, Card.ace_of_diamonds);
        assertFalse(unitUnderTest.isBlackJack());
        unitUnderTest = new Hand(player, 1, Card.nine_of_diamonds, Card.five_of_hearts);
        assertFalse(unitUnderTest.isBlackJack());
        unitUnderTest = new Hand(player, 1, Card.ten_of_clubs, Card.ace_of_clubs);
        assertFalse(unitUnderTest.isBlackJack());
        unitUnderTest = new Hand(player, 1, Card.jack_of_clubs, Card.ace_of_clubs);
        assertTrue(unitUnderTest.isBlackJack());
        unitUnderTest = new Hand(player, 1, Card.ace_of_clubs, Card.jack_of_clubs);
        assertTrue(unitUnderTest.isBlackJack());
    }

    @Test
    void countCards() {
        for (int i = 0; i < 10; i++) {
            assertEquals(i, unitUnderTest.countCards());
            unitUnderTest.draw(Card.five_of_hearts);
        }
    }

    @Test
    void containsAny() {
        assertFalse(unitUnderTest.containsAny());
        unitUnderTest.draw(Card.five_of_hearts);
        assertTrue(unitUnderTest.containsAny());
        assertFalse(unitUnderTest.containsAny(CardValue.eight));
        assertTrue(unitUnderTest.containsAny(CardValue.eight, CardValue.five));
        unitUnderTest.draw(Card.eight_of_diamonds);
        assertTrue(unitUnderTest.containsAny(CardValue.eight));
    }

    @Test
    void placeBet() {
        Player a = new Player("a");
        Player b = new Player("b");
        for (int i = 0; i < 20; i++) {
            // note that the hand will assume that the player already paid
            assertDoesNotThrow(() -> unitUnderTest.placeBet(a, random.nextInt(1000)));
            assertDoesNotThrow(() -> unitUnderTest.placeBet(b, random.nextInt(1000)));
        }
    }

    @Test
    void getBet() {
        Player a = new Player("a");

        int amount = unitUnderTest.getBet(player);
        assertEquals(amount, unitUnderTest.getBet(player));
        assertEquals(0, unitUnderTest.getBet(a));

        unitUnderTest.placeBet(player, 10);
        unitUnderTest.placeBet(a, 0);
        assertEquals(amount+10, unitUnderTest.getBet(player));
        assertEquals(0, unitUnderTest.getBet(a));

        unitUnderTest.placeBet(player, 100);
        unitUnderTest.placeBet(a, 30);
        assertEquals(amount+110, unitUnderTest.getBet(player));
        assertEquals(30, unitUnderTest.getBet(a));
    }

    @Test
    void getSupporters() {
        Player a = new Player("a");
        Player b = new Player("b");
        Player c = new Player("c");

        unitUnderTest.placeBet(a, 10);
        unitUnderTest.placeBet(b, 0);
        assertEquals(Set.of(player, a), new HashSet<>(unitUnderTest.getSupporters()));
        unitUnderTest.placeBet(a, 10);
        unitUnderTest.placeBet(c, 0);
        assertEquals(Set.of(player, a), new HashSet<>(unitUnderTest.getSupporters()));
        unitUnderTest.placeBet(c, 1000);
        assertEquals(Set.of(player, a, c), new HashSet<>(unitUnderTest.getSupporters()));
    }

    @Test
    void isSplittable() {
        unitUnderTest = new Hand(player, 1, Card.ace_of_clubs);
        assertFalse(unitUnderTest.isSplittable());
        unitUnderTest = new Hand(player, 1, Card.ace_of_clubs, Card.jack_of_clubs);
        assertFalse(unitUnderTest.isSplittable());
        unitUnderTest = new Hand(player, 1, Card.ace_of_clubs, Card.jack_of_clubs, Card.nine_of_clubs);
        assertFalse(unitUnderTest.isSplittable());
        unitUnderTest = new Hand(player, 1, Card.ace_of_clubs, Card.ace_of_diamonds);
        assertTrue(unitUnderTest.isSplittable());
        unitUnderTest = new Hand(player, 1, Card.three_of_clubs, Card.three_of_clubs);
        assertTrue(unitUnderTest.isSplittable());
    }

    @Test
    void draw() {
        for (int i = 0; i < 100; i++) {
            assertDoesNotThrow(() -> unitUnderTest.draw(Card.seven_of_hearts));
        }
    }

    @Test
    void split() {
        unitUnderTest = new Hand(player, 1, Card.three_of_clubs, Card.three_of_hearts);
        assertEquals(6, unitUnderTest.value());
        Hand split = unitUnderTest.split();
        assertEquals(3, unitUnderTest.value());
        assertEquals(3, split.value());

    }
}