package test;

import helpers.FileIO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import translation.BooleanTranslator;

import static org.junit.jupiter.api.Assertions.*;

class FileIOTest {

    @Test
    void loadBooleanTranslator() {
        FileIO.setTestMode(true);
        assertDoesNotThrow(FileIO::loadBooleanTranslator);
        FileIO.setTestMode(false);
    }

    @Test
    void saveBooleanTranslator() {
        FileIO.setTestMode(true);
        assertDoesNotThrow(() -> FileIO.saveBooleanTranslator(new BooleanTranslator()));
        FileIO.setTestMode(false);
    }

    @Test
    void loadIntTranslator() {
        FileIO.setTestMode(true);
        assertDoesNotThrow(FileIO::loadIntTranslator);
        FileIO.setTestMode(false);
    }

    @Test
    void saveIntTranslator() {
        FileIO.setTestMode(true);
        assertDoesNotThrow(() -> FileIO.saveIntTranslator(null));
        FileIO.setTestMode(false);
    }

    @Test
    void loadActionTranslator() {
        FileIO.setTestMode(true);
        assertDoesNotThrow(FileIO::loadActionTranslator);
        FileIO.setTestMode(false);
    }

    @Test
    void saveActionTranslator() {
        FileIO.setTestMode(true);
        assertDoesNotThrow(() -> FileIO.saveActionTranslator(null));
        FileIO.setTestMode(false);
    }

    @Test
    void loadSynonymTranslator() {
        FileIO.setTestMode(true);
        assertDoesNotThrow(() -> FileIO.loadSynonymTranslator("test"));
        FileIO.setTestMode(false);
    }

    @Test
    void saveSynonymTranslator() {
        FileIO.setTestMode(true);
        assertDoesNotThrow(() -> FileIO.saveSynonymTranslator(null, "test"));
        FileIO.setTestMode(false);
    }

    @Test
    void loadPlayer() {
        FileIO.setTestMode(true);
        assertDoesNotThrow(() -> FileIO.loadPlayer("test"));
        FileIO.setTestMode(false);
    }

    @Test
    void savePlayer() {
        FileIO.setTestMode(true);
        assertDoesNotThrow(() -> FileIO.savePlayer("test", null));
        FileIO.setTestMode(false);
    }
}