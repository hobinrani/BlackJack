package test;

import constants.Action;
import constants.Card;
import constants.Dialog;
import helpers.FileIO;
import main.Application;
import model.Game;
import model.Player;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import translation.SynonymTranslator;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class ApplicationTest {

    LinkedList<String> inputBuf;
    LinkedList<String> outputBuf;
    LinkedList<String> expected;
    LinkedList<Card> deck;
    Map<String, Player> playerBase;

    @BeforeEach
    void setUp() {
        FileIO.setTestMode(true);
        
        inputBuf = new LinkedList<>();
        outputBuf = new LinkedList<>();
        expected = new LinkedList<>();
        deck = new LinkedList<>();
        playerBase = new HashMap<>();
        
        Application.useInputSupplier(inputBuf::pollFirst);
        Application.useOutputConsumer(outputBuf::add);
        Application.useCardSupplier(deck::pollFirst);
        Application.usePlayerLoader(playerBase::get, playerBase::put);
        Application.useSynonymTranslator(new DummySynonymTranslator());
    }

    @AfterEach
    void tearDown() {
        FileIO.setTestMode(false);
    }

    @Test
    void simulation() {

        Player a = new Player("player a");
        a.pay(Game.DEFAULT_STARTING_BALANCE);
        a.gain(200); // starting balance 200
        playerBase.put("player a", a);

        Player b = new Player("player b");
        b.pay(10); // starting balance below default (should be reset)
        playerBase.put("player b", b);

        //////// RENDEZVOUS PHASE
        expected.add(Dialog.hello);
        expected.add(Dialog.name);
        inputBuf.add("player a");
        expected.add(Dialog.welcomeWinner);
        expected.add(Dialog.bringFriends);
        inputBuf.add("test no");
        expected.add(Dialog.specifyBoolean);
        inputBuf.add("no");

        //////// MAIN BET PHASE
        expected.add(Dialog.address);
        expected.add(Dialog.betAmount);
        inputBuf.add("test 10k");
        expected.add(Dialog.specifyInt);
        inputBuf.add("10000");
        expected.add(Dialog.insufficientBalance);
        expected.add(Dialog.betAmount);
        inputBuf.add("20"); // balance a: 180$

        //////// SIDE BET PHASE (skipped)

        //////// HAND INITIATION PHASE
        // cards dealt to player
        deck.add(Card.ace_of_clubs);
        deck.add(Card.ace_of_diamonds); // main hand -> double ace

        //////// ACTION PHASE
        expected.add(Dialog.address);
        expected.add(Dialog.mainHand);
        expected.add(Dialog.action);
        inputBuf.add("test split");
        expected.add(Dialog.specifyAction);
        inputBuf.add("split");
        expected.add(Dialog.confirmSplit); // balance a: 160$

        // cards dealt to player
        deck.add(Card.king_of_spades); // main hand -> black jack
        deck.add(Card.two_of_hearts); // split hand -> 13

        // main hand action
        setupAction(Dialog.mainHand, Action.stand, Dialog.confirmStand);
        // split hand action
        setupAction(Dialog.secondHand, Action.doubleDown, Dialog.confirmDoubleDown); // balance a: 140$

        // card dealt to player
        deck.add(Card.five_of_hearts); // split hand -> 18

        //////// RESOLVE PHASE
        // cards dealt to dealer
        deck.add(Card.king_of_spades); // 10
        deck.add(Card.two_of_hearts); // 12
        deck.add(Card.six_of_clubs); // 18

        expected.add(Dialog.dealerHand);
        expected.add(Dialog.dealerHit);
        expected.add(Dialog.dealerHandUpdated);
        // main hand a
        expected.add(Dialog.address);
        expected.add(Dialog.playerWins);
        expected.add(Dialog.address);
        expected.add(Dialog.payday); // balance a: 180$
        // split hand a
        expected.add(Dialog.address);
        expected.add(Dialog.tie);
        expected.add(Dialog.address);
        expected.add(Dialog.refund); // balance a: 220$

        //////// CLOSE PHASE
        expected.add(Dialog.roundEnd);
        expected.add(Dialog.anyoneJoin);
        inputBuf.add("yes");

        //////// RENDEZVOUS PHASE
        expected.add(Dialog.hello);
        expected.add(Dialog.name);
        inputBuf.add("player b");
        expected.add(Dialog.welcomeLoser);
        expected.add(Dialog.anyoneJoin);
        inputBuf.add("no");

        //////// MAIN BET PHASE
        // player a: 0 (skip round)
        expected.add(Dialog.address);
        expected.add(Dialog.betAmount);
        inputBuf.add("0");
        // player b: 0 (skip round)
        expected.add(Dialog.address);
        expected.add(Dialog.betAmount);
        inputBuf.add("0");

        //////// SIDE BET PHASE (skipped)

        //////// HAND INITIATION PHASE (empty)

        //////// ACTION PHASE (skipped)

        //////// RESOLVE PHASE (skipped)

        //////// CLOSE PHASE
        expected.add(Dialog.roundEnd);
        expected.add(Dialog.anyoneJoin);
        inputBuf.add("no");

        //////// MAIN BET PHASE
        // player a
        expected.add(Dialog.address);
        expected.add(Dialog.betAmount);
        inputBuf.add("10"); // balance a: 210$
        // player b
        expected.add(Dialog.address);
        expected.add(Dialog.betAmount);
        inputBuf.add("100"); // balance b: 0$

        //////// SIDE BET PHASE
        //player a
        expected.add(Dialog.address);
        expected.add(Dialog.sideBet);
        inputBuf.add("yes");
        expected.add(Dialog.sideBetName);
        inputBuf.add("player x");
        expected.add(Dialog.noBetPresent);
        expected.add(Dialog.sideBetName);
        inputBuf.add("player b");
        expected.add(Dialog.betAmount);
        inputBuf.add("10000");
        expected.add(Dialog.insufficientBalance);
        expected.add(Dialog.betAmount);
        inputBuf.add("10"); // balance a: 200$
        expected.add(Dialog.sideBet);
        inputBuf.add("no");

        //////// HAND INITIATION PHASE
        // player a
        deck.add(Card.king_of_diamonds);
        deck.add(Card.king_of_hearts); // main hand a: double king
        // player b
        deck.add(Card.two_of_hearts);
        deck.add(Card.three_of_clubs); // main hand b: 2+3

        //////// ACTION PHASE
        // player a
        setupAction(Dialog.mainHand, Action.split, Dialog.confirmSplit); // balance a: 190$
        deck.add(Card.king_of_spades); // main hand a: double king
        deck.add(Card.seven_of_clubs); // split hand a: 10+7
        setupAction(Dialog.mainHand, Action.split, Dialog.confirmSplit); // balance a: 180$
        deck.add(Card.four_of_hearts); // main hand a: 10+4
        deck.add(Card.five_of_clubs); // third hand a: 10+5
        setupAction(Dialog.mainHand, Action.split, Dialog.actionDenied);
        setupAction(Dialog.mainHand, Action.stand, Dialog.confirmStand);
        setupAction(Dialog.secondHand, Action.stand, Dialog.confirmStand);
        setupAction(Dialog.otherHand, Action.hit, Dialog.confirmHit);

        deck.add(Card.ace_of_clubs); // third hand a: 10+5+1

        setupAction(Dialog.otherHand, Action.doubleDown, Dialog.actionDenied);
        setupAction(Dialog.otherHand, Action.stand, Dialog.confirmStand);

        // player b
        setupAction(Dialog.mainHand, Action.doubleDown, Dialog.notAffordable);
        setupAction(Dialog.mainHand, Action.stand, Dialog.confirmStand);

        //////// RESOLVE PHASE
        deck.add(Card.ten_of_clubs);
        deck.add(Card.ten_of_diamonds); // dealer: 10+10

        expected.add(Dialog.dealerHand);
        // main hand a
        expected.add(Dialog.address);
        expected.add(Dialog.playerLoses);
        // split hand a
        expected.add(Dialog.address);
        expected.add(Dialog.playerLoses);
        // third hand a
        expected.add(Dialog.address);
        expected.add(Dialog.playerLoses);
        // main hand b
        expected.add(Dialog.address);
        expected.add(Dialog.playerLoses);

        //////// CLOSE PHASE
        expected.add(Dialog.roundEnd);
        // player b drops out
        expected.add(Dialog.address);
        expected.add(Dialog.playerBroke);
        expected.add(Dialog.anyoneJoin);
        inputBuf.add("yes");

        //////// RENDEZVOUS PHASE
        expected.add(Dialog.hello);
        expected.add(Dialog.name);
        inputBuf.add("player a");
        expected.add(Dialog.nameCollision);
        expected.add(Dialog.name);
        inputBuf.add("player c");
        expected.add(Dialog.welcomeUnknown);
        expected.add(Dialog.anyoneJoin);
        inputBuf.add("no");

        //////// MAIN BET PHASE
        setupBet(100); // balance a: 80$
        setupBet(Game.DEFAULT_STARTING_BALANCE); // balance c: 0$

        //////// SIDE BET PHASE
        // player a
        expected.add(Dialog.address);
        expected.add(Dialog.sideBet);
        inputBuf.add("no");

        //////// HAND INITIATION PHASE
        // player a
        deck.add(Card.eight_of_clubs);
        deck.add(Card.two_of_hearts); // main hand a: 8+2
        // player c
        deck.add(Card.queen_of_hearts);
        deck.add(Card.seven_of_clubs); // main hand c: 10+7

        //////// ACTION PHASE
        // player a
        setupAction(Dialog.mainHand, Action.stand, Dialog.confirmStand);
        // player c
        setupAction(Dialog.mainHand, Action.hit, Dialog.confirmHit);
        deck.add(Card.jack_of_spades); // main hand c: 10+7+10 -> busted
        expected.add(Dialog.playerBusted);

        //////// RESOLVE PHASE
        deck.add(Card.ten_of_spades);
        deck.add(Card.five_of_clubs); // dealer: 10+5
        deck.add(Card.nine_of_hearts); // dealer: 10+5+9 -> busted

        expected.add(Dialog.dealerHand);
        expected.add(Dialog.dealerHit);
        expected.add(Dialog.dealerBusted);
        // main hand a
        expected.add(Dialog.address);
        expected.add(Dialog.playerWins);
        expected.add(Dialog.address);
        expected.add(Dialog.payday); // balance a: 280$

        //////// CLOSE PHASE
        expected.add(Dialog.roundEnd);
        // player c drops out
        expected.add(Dialog.address);
        expected.add(Dialog.playerBroke);
        expected.add(Dialog.anyoneJoin);
        inputBuf.add("no");

        //////// MAIN BET PHASE
        setupBet(280);  // balance a: 0$

        //////// SIDE BET PHASE (skipped)

        //////// ACTION PHASE
        setupAction(Dialog.mainHand, Action.stand, Dialog.confirmStand);

        //////// HNAD INITIATION PHASE
        deck.add(Card.two_of_clubs);
        deck.add(Card.five_of_diamonds); // main hand a: 2+4

        //////// RESOLVE PHASE
        deck.add(Card.king_of_diamonds);
        deck.add(Card.ace_of_diamonds); // dealer: black jack

        expected.add(Dialog.dealerHand);
        expected.add(Dialog.dealerBlackjack);

        //////// CLOSE PHASE
        expected.add(Dialog.roundEnd);
        // player a drops out
        expected.add(Dialog.address);
        expected.add(Dialog.playerBroke);
        expected.add(Dialog.anyoneJoin);
        inputBuf.add("no");

        //////// GAME OVER
        expected.add(Dialog.farewell);

        // RUN SIMULATION
        Application.main(new String[] {});

        assertEquals(expected, outputBuf);
    }


    private void setupAction(String handDialog, Action action, String answer) {
        expected.add(Dialog.address);
        expected.add(handDialog);
        expected.add(Dialog.action);
        inputBuf.add(action.name());
        expected.add(answer);
    }
    
    private void setupBet(int amount) {
        expected.add(Dialog.address);
        expected.add(Dialog.betAmount);
        inputBuf.add(""+amount);
    }

    private static class DummySynonymTranslator extends SynonymTranslator {
        @Override
        public String translate(String key) {
            return key;
        }
    }
}