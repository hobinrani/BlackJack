package test;

import constants.Card;
import model.AutoRestockDeck;
import org.junit.jupiter.api.Test;

import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class AutoRestockDeckTest {

    @Test
    void get() {

        // draw one full deck, then every card must have been drawn once
        AutoRestockDeck unitUnderTest = new AutoRestockDeck();
        Set<Card> drawn = new HashSet<>();
        Set<Card> all = new HashSet<>();
        for (Card card1 : Card.values()) {
            Card card2 = unitUnderTest.get();
            assertNotNull(card2);
            drawn.add(card2);
            all.add(card1);
        }
        assertEquals(all, drawn);
    }
}