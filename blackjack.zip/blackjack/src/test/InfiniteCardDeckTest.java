package test;

import constants.Card;
import model.InfiniteCardDeck;
import org.junit.jupiter.api.Test;


import static org.junit.jupiter.api.Assertions.*;

class InfiniteCardDeckTest {

    @Test
    void get() {

        // we could test fairness, but probabilities are hard to measure
        // look at the code, it always returns a random card.
        InfiniteCardDeck unitUnderTest = new InfiniteCardDeck();
        for (int i = 0; i < 1000; i++) {
            Card card2 = unitUnderTest.get();
            assertNotNull(card2);
        }
    }

}