package cli;

import constants.Dialog;
import model.Player;
import constants.Action;
import helpers.FileIO;
import translation.ActionTranslator;
import translation.BooleanTranslator;
import translation.IntTranslator;
import translation.SynonymTranslator;

import java.util.function.Consumer;
import java.util.function.Supplier;

public class ChatBot {

    private final BooleanTranslator booleanTranslator = FileIO.loadBooleanTranslator();
    private final IntTranslator intTranslator = FileIO.loadIntTranslator();
    private final ActionTranslator actionTranslator = FileIO.loadActionTranslator();
    private SynonymTranslator synonymTranslator;

    private Supplier<String> in;
    private Consumer<String> out;

    public ChatBot(SynonymTranslator synonymTranslator, Supplier<String> in, Consumer<String> out) {
        this.synonymTranslator = synonymTranslator;
        this.in = in;
        this.out = out;
    }

    /**
     * strategy pattern to allow testability
     * @param in supplier of user input
     */
    public void useInputSupplier(Supplier<String> in) {
        this.in = in;
    }

    /**
     * strategy pattern to allow testability.
     * @param out consumer of chat output
     */
    public void useOutputConsumer(Consumer<String> out) {
        this.out = out;
    }

    /**
     * changes the synonym translator of the game
     */
    public void useSynonymTranslator(SynonymTranslator synonymTranslator) {
        this.synonymTranslator = synonymTranslator;
    }

    private String inputString(String question, boolean askQuestion) {
        if (askQuestion) out.accept(question);
        return in.get();
    }

    private int inputInt(String question, boolean askQuestion) {
        String answer = inputString(question, askQuestion);
        if (answer == null) return 0;
        if (!intTranslator.containsKey(answer)) {
            declare(Dialog.specifyInt);
            intTranslator.put(answer, inputInt(question, false));
        }
        return intTranslator.get(answer);
    }

    private Action inputAction(String question, boolean askQuestion) {
        String answer = inputString(question, askQuestion);
        if (answer == null) return null;
        if (!actionTranslator.containsKey(answer)) {
            declare(Dialog.specifyAction);
            actionTranslator.put(answer, inputAction(question, false));
        }
        return actionTranslator.get(answer);
    }

    private boolean inputBoolean(String question, boolean askQuestion) {
        String answer = inputString(question, askQuestion);
        if (answer == null) return false;
        if (!booleanTranslator.containsKey(answer)) {
            declare(Dialog.specifyBoolean);
            booleanTranslator.put(answer, inputBoolean(question, false));
        }
        return booleanTranslator.get(answer);
    }

    public void declare(String string) {
        out.accept(synonymTranslator.translate(string));
    }

    public void declare(String string, Player addressee) {
        out.accept(String.format(synonymTranslator.translate(string), addressee.getName()));
    }

    public void declare(String string, Object arg) {
        out.accept(String.format(synonymTranslator.translate(string), arg));
    }

    public String askString(String questionKey) {
        return inputString(synonymTranslator.translate(questionKey), true);
    }

    public boolean askBoolean(String questionKey) {
        return inputBoolean(synonymTranslator.translate(questionKey), true);
    }

    public int askInt(String questionKey) {
        return inputInt(synonymTranslator.translate(questionKey), true);
    }

    public Action askAction(String questionKey) {
        return inputAction(synonymTranslator.translate(questionKey), true);
    }


    public void saveTranslators() {
        FileIO.saveBooleanTranslator(booleanTranslator);
        FileIO.saveIntTranslator(intTranslator);
        FileIO.saveActionTranslator(actionTranslator);
        FileIO.saveSynonymTranslator(synonymTranslator, synonymTranslator.translate("synonymTranslatorFilename"));
    }
}
