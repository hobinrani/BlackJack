package model;

import constants.Card;
import constants.CardValue;

import java.util.*;

public class Hand {

    private final Player owner;

    private final List<Card> cards = new ArrayList<>();

    private final Map<Player, Integer> bets = new HashMap<>();

    public Hand(Player owner, int ownerBet, Card... initialCards) {
        this.owner = owner;
        placeBet(owner, ownerBet);
        for (Card c : initialCards) draw(c);
    }

    /**
     * Only for cli.ChatBot hand. Cannot serve all actions.
     */
    public Hand() {
        owner = null;
    }

    public boolean isBusted() {
        return value() > 21;
    }

    public int value() {
        Set<Integer> ambiguousValues = ambiguousValues();
        int max = 0, best = 0;
        for (int i : ambiguousValues) {
            max = Math.max(i, max);
            best = i > 21? best : Math.max(i, best);
        }
        return best == 0? max : best;
    }

    public Set<Integer> ambiguousValues() {
        Set<Integer> result = Collections.singleton(0);
        for (Card card : cards) {
            Set<Integer> tmp = new HashSet<>();
            for (int v : result) for (int o : card.value.values) {
                tmp.add(v+o);
            }
            result = tmp;
        }
        return result;
    }

    public boolean isAmbiguous() {
        return cards.stream().anyMatch(c -> c.value.values.length > 1);
    }

    public boolean isBlackJack() {
        return cards.size() == 2 && containsAny(CardValue.ace) && (containsAny(CardValue.jack, CardValue.queen, CardValue.king));
    }

    public int countCards() {
        return cards.size();
    }

    /**
     * @return whether this hand contains any of the given card values
     */
    public boolean containsAny(CardValue... query) {
        if (query.length == 0) return !cards.isEmpty();
        for (CardValue cv : query) if (cards.stream().anyMatch(c -> c.value == cv)) return true;
        return false;
    }

    public void placeBet(Player player, int amount) {
        if (amount == 0) return;
        bets.put(player, bets.getOrDefault(player, 0) +amount);
    }

    public int getBet(Player player) {
        return bets.getOrDefault(player, 0);
    }

    public Collection<Player> getSupporters() {
        return bets.keySet();
    }

    public boolean isSplittable() {
        return owner != null && cards.size() == 2 && cards.get(0).value == cards.get(1).value;
    }

    public void draw(Card card) {
        cards.add(card);
    }

    public Hand split() {
        if (!isSplittable()) throw new IllegalStateException();
        Card splitCard = cards.remove(1);
        return new Hand(owner, owner.pay(bets.get(owner)), splitCard);
    }

    @Override
    public String toString() {
        return isBlackJack()? String.format("%s (Black Jack!)", cards) : String.format("%s (%d)", cards, value());
    }
}
