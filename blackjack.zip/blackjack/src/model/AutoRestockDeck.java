package model;

import constants.Card;

import java.util.Arrays;
import java.util.Collections;
import java.util.Random;
import java.util.Stack;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class AutoRestockDeck implements Supplier<Card> {

    private final Random r = new Random();

    private Stack<Card> stack = newStack();

    protected Card[] selectionSpace() {
        return Card.values();
    }

    protected Stack<Card> newStack() {
        Stack<Card> stack = new Stack<>();
        stack.addAll(Arrays.asList(selectionSpace()));
        Collections.shuffle(stack);
        return stack;
    }

    /**
     * @return a random card. May return the same card multiple times because the deck is infinite.
     */
    @Override
    public Card get() {
        if (stack.isEmpty()) stack = newStack();
        return stack.pop();
    }
}
