package model;

import constants.Card;

import java.util.Random;
import java.util.function.Supplier;

public class InfiniteCardDeck implements Supplier<Card> {

    private final Random r = new Random();

    protected Card[] selectionSpace() {
        return Card.values();
    }

    /**
     * @return a random card. May return the same card multiple times because the deck is infinite.
     */
    @Override
    public Card get() {
        Card[] cards = selectionSpace();
        return cards[r.nextInt(cards.length)];
    }
}
