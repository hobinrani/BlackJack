package model;

import java.io.Serializable;

public class Player implements Serializable {
    protected static final long serialVersionUID = 13;

    private final String name;
    private int balance;

    public Player(String name) {
        this.name = name;
        resetBalance();
    }

    public String getName() {
        return name;
    }

    public int getBalance() {
        return balance;
    }

    public void resetBalance() {
        balance = Game.DEFAULT_STARTING_BALANCE;
    }

    /**
     * @return whether the player's balance is larger or equals the given amount
     */
    public boolean canAfford(int amount) {
        return balance >= amount;
    }

    /**
     * @param amount to withdraw from the player's balance
     * @return the same amount
     * @throws IllegalStateException if player cannot afford this amount
     */
    public int pay(int amount) {
        if (amount < 0) throw new IllegalArgumentException();
        if (!canAfford(amount)) throw new IllegalStateException();
        balance -= amount;
        return amount;
    }

    public void gain(int amount) {
        if (amount < 0) throw new IllegalArgumentException();
        balance += amount;
    }
}
