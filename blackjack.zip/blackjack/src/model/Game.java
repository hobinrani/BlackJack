package model;

import cli.ChatBot;
import constants.Card;
import constants.Dialog;
import translation.SynonymTranslator;

import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

public class Game implements Runnable {

    public static final int DEFAULT_STARTING_BALANCE = 100;


    private final ChatBot chat;
    private final List<Player> players = new ArrayList<>();
    private final Map<String, List<Hand>> hands = new HashMap<>();
    private Supplier<Card> deck;
    private Function<String, Player> playerLoader;
    private BiConsumer<String, Player> playerStore;

    public Game(ChatBot chat, Supplier<Card> deck, Function<String, Player> playerLoader, BiConsumer<String, Player> playerStore) {
        this.chat = chat;
        this.deck = deck;
        this.playerLoader = playerLoader;
        this.playerStore = playerStore;
    }

    /**
     * strategy pattern to allow testability
     * @param in supplier of user input
     */
    public void useInputSupplier(Supplier<String> in) {
        chat.useInputSupplier(in);
    }

    /**
     * strategy pattern to allow testability.
     * @param out consumer of chat output
     */
    public void useOutputConsumer(Consumer<String> out) {
        chat.useOutputConsumer(out);
    }

    /**
     * strategy pattern to allow testability
     * @param deck supplier of cards
     */
    public void useCardSupplier(Supplier<Card> deck) {
        this.deck = deck;
    }

    /**
     * strategy pattern to allow testability.
     * @param playerLoader strategy to load a player
     * @param playerStore strategy to store a player
     */
    public void usePlayerLoader(Function<String, Player> playerLoader, BiConsumer<String, Player> playerStore) {
        this.playerLoader = playerLoader;
        this.playerStore = playerStore;
    }

    /**
     * changes the synonym translator of the game
     */
    public void useSynonymTranslator(SynonymTranslator synonymTranslator) {
        chat.useSynonymTranslator(synonymTranslator);
    }

    @Override
    public void run() {

        rendezvous();

        while (canStartRound()) {

            collectMainBets();
            collectSideBets();
            initHands();
            servePlayerActions();
            resolveRound();
            closeRound();
        }
        dismiss();

    }

    private boolean nameCollides(String name) {
        return players.stream().anyMatch(p -> p.getName().equals(name));
    }

    private void fillHand(Hand hand) {
        while (hand.countCards() < 2) hand.draw(deck.get());
    }

    private int countLivingHands() {
        return (int) hands.values().stream().mapToLong(list -> list.stream().filter(hand -> !hand.isBusted()).count()).sum();
    }

    public void rendezvous() {
        do {
            chat.declare(Dialog.hello);
            String name;
            while (nameCollides(name = chat.askString(Dialog.name))) {
                chat.declare(Dialog.nameCollision);
            }
            Player player = playerLoader.apply(name);
            if (player == null) {
                player = new Player(name);
                chat.declare(Dialog.welcomeUnknown, player);
            } else if (!player.canAfford(Game.DEFAULT_STARTING_BALANCE)) {
                player.resetBalance();
                chat.declare(Dialog.welcomeLoser, player);
            } else {
                chat.declare(Dialog.welcomeWinner, player);
            }
            players.add(player);

        } while (chat.askBoolean(players.size() < 2? Dialog.bringFriends : Dialog.anyoneJoin));
    }

    public boolean canStartRound() {
        return !players.isEmpty();
    }

    public void collectMainBets() {
        for (Player p : players) {
            chat.declare(Dialog.address, p);
            int amount;
            while (!p.canAfford(amount = chat.askInt(Dialog.betAmount))) {
                chat.declare(Dialog.insufficientBalance, p.getBalance());
            }
            if (amount > 0) {
                List<Hand> playerHands = new ArrayList<>();
                playerHands.add(new Hand(p, p.pay(amount)));
                hands.put(p.getName(), playerHands);
            }
        }
    }

    public void collectSideBets() {
        if (countLivingHands() < 2) return;

        for (Player player : players) {
            if (!player.canAfford(1)) continue;
            chat.declare(Dialog.address, player);
            while (player.canAfford(1) && chat.askBoolean(Dialog.sideBet)) {
                String name;
                while (!hands.containsKey(name = chat.askString(Dialog.sideBetName))) {
                    chat.declare(Dialog.noBetPresent, player.getBalance());
                }
                int amount;
                while (!player.canAfford(amount = chat.askInt(Dialog.betAmount))) {
                    chat.declare(Dialog.insufficientBalance, player.getBalance());
                }
                hands.get(name).get(0).placeBet(player, player.pay(amount));
            }
        }
    }

    public void initHands() {
        for (Player player : players) {
            List<Hand> list = hands.get(player.getName());
            if (list != null) for (Hand hand : list) {
                fillHand(hand);
            }
        }
    }

    public void servePlayerActions() {
        for (Player player : players) {
            List<Hand> hands = this.hands.get(player.getName());
            if (hands == null) continue;
            for (int i = 0; i < hands.size();) {
                Hand hand = hands.get(i);
                chat.declare(Dialog.address, player);
                chat.declare(i == 0? Dialog.mainHand : i == 1? Dialog.secondHand : Dialog.otherHand, hand);
                switch (chat.askAction(Dialog.action)) {
                    case stand -> {
                        chat.declare(Dialog.confirmStand);
                        i++; // stand does not allow follow-up actions
                    }
                    case hit -> {
                        chat.declare(Dialog.confirmHit);
                        hand.draw(deck.get());
                        if (hand.isBusted()) {
                            chat.declare(Dialog.playerBusted, hand);
                            hands.remove(i);
                        }
                    }
                    case split -> {
                        if (hand.isSplittable()) {
                            chat.declare(Dialog.confirmSplit);
                            Hand split = hand.split();
                            hands.add(split);
                            fillHand(hand);
                            fillHand(split);
                        } else {
                            chat.declare(Dialog.actionDenied);
                        }
                    }
                    case doubleDown -> {
                        int amount = hand.getBet(player);
                        if (hand.countCards() != 2) {
                            chat.declare(Dialog.actionDenied);
                        } else if (!player.canAfford(amount)) {
                            chat.declare(Dialog.notAffordable);
                        } else {
                            chat.declare(Dialog.confirmDoubleDown);
                            hand.placeBet(player, player.pay(amount));
                            hand.draw(deck.get());
                            if (hand.isBusted()) {
                                chat.declare(Dialog.playerBusted, hand);
                                hands.remove(i);
                            }
                            i++; // double down does not allow follow-up actions
                        }
                    }
                }
            }
        }
    }

    public void resolveRound() {
        if (countLivingHands() == 0) return;

        Hand dealerHand = new Hand();
        fillHand(dealerHand);
        chat.declare(Dialog.dealerHand, dealerHand);

        while (dealerHand.value() < 17) {
            chat.declare(Dialog.dealerHit);
            dealerHand.draw(deck.get());
            if (dealerHand.isBusted()) {
                chat.declare(Dialog.dealerBusted, dealerHand);
            } else {
                chat.declare(Dialog.dealerHandUpdated, dealerHand);
            }
        }

        if (dealerHand.isBlackJack()) {
            chat.declare(Dialog.dealerBlackjack, dealerHand);
            return;
        }

        for (Player player : players) {
            List<Hand> hands = this.hands.get(player.getName());
            for (Hand hand : hands) {
                chat.declare(Dialog.address, player);
                if (dealerHand.isBusted() || hand.isBlackJack() || hand.value() > dealerHand.value()) {
                    chat.declare(Dialog.playerWins, hand);
                    for (Player supporter: hand.getSupporters()) {
                        int amount = hand.getBet(supporter);
                        chat.declare(Dialog.address, supporter);
                        chat.declare(Dialog.payday, amount);
                        supporter.gain(amount * 2);
                    }
                } else if (hand.value() == dealerHand.value()) {
                    chat.declare(Dialog.tie, hand);
                    for (Player supporter: hand.getSupporters()) {
                        int amount = hand.getBet(supporter);
                        chat.declare(Dialog.address, supporter);
                        chat.declare(Dialog.refund, amount);
                        supporter.gain(amount);
                    }
                } else {
                    chat.declare(Dialog.playerLoses, hand);
                }
            }
        }
    }

    public void closeRound() {
        savePlayers();
        chat.saveTranslators();
        chat.declare(Dialog.roundEnd);
        hands.clear();
        Iterator<Player> iter = players.iterator();
        while (iter.hasNext()) {
            Player player = iter.next();
            if (!player.canAfford(1)) {
                chat.declare(Dialog.address, player);
                chat.declare(Dialog.playerBroke);
                iter.remove();
            }
        }

        if (chat.askBoolean(Dialog.anyoneJoin)) {
            rendezvous();
        }
    }

    public void dismiss() {
        savePlayers();
        players.clear();
        chat.declare(Dialog.farewell);
        chat.saveTranslators();
    }

    public void savePlayers() {
        players.forEach(p -> playerStore.accept(p.getName(), p));
    }

}
