package helpers;

import model.Player;
import translation.ActionTranslator;
import translation.BooleanTranslator;
import translation.IntTranslator;
import translation.SynonymTranslator;

import java.io.*;
import java.util.Objects;

public abstract class FileIO {


    private static boolean testMode;
    public static void setTestMode(boolean b) {
        testMode = b;
    }

    public static BooleanTranslator loadBooleanTranslator() {
        try {
            File file = new File(testMode? "test.test" : "data/booleans.ser");
            FileInputStream fin = new FileInputStream(file);
            ObjectInputStream oin = new ObjectInputStream(fin);
            BooleanTranslator res = (BooleanTranslator) oin.readObject();
            oin.close();
            fin.close();
            return Objects.requireNonNull(res);
        } catch (Exception e) {
            return new BooleanTranslator();
        }
    }

    public static void saveBooleanTranslator(BooleanTranslator t) {
        try {
            File file = new File(testMode? "test.test" : "data/booleans.ser");
            FileOutputStream fout = new FileOutputStream(file);
            ObjectOutputStream oout = new ObjectOutputStream(fout);
            oout.writeObject(t);
            oout.close();
            fout.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static IntTranslator loadIntTranslator() {
        try {
            File file = new File(testMode? "test.test" : "data/ints.ser");
            FileInputStream fin = new FileInputStream(file);
            ObjectInputStream oin = new ObjectInputStream(fin);
            IntTranslator res = (IntTranslator) oin.readObject();
            oin.close();
            fin.close();
            return Objects.requireNonNull(res);
        } catch (Exception e) {
            return new IntTranslator();
        }
    }

    public static void saveIntTranslator(IntTranslator t) {
        try {
            File file = new File(testMode? "test.test" : "data/ints.ser");
            FileOutputStream fout = new FileOutputStream(file);
            ObjectOutputStream oout = new ObjectOutputStream(fout);
            oout.writeObject(t);
            oout.close();
            fout.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static ActionTranslator loadActionTranslator() {
        try {
            File file = new File(testMode? "test.test" : "data/actions.ser");
            FileInputStream fin = new FileInputStream(file);
            ObjectInputStream oin = new ObjectInputStream(fin);
            ActionTranslator res = (ActionTranslator) oin.readObject();
            oin.close();
            fin.close();
            return Objects.requireNonNull(res);
        } catch (Exception e) {
            return new ActionTranslator();
        }
    }

    public static void saveActionTranslator(ActionTranslator t) {
        try {
            File file = new File(testMode? "test.test" : "data/actions.ser");
            FileOutputStream fout = new FileOutputStream(file);
            ObjectOutputStream oout = new ObjectOutputStream(fout);
            oout.writeObject(t);
            oout.close();
            fout.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static SynonymTranslator loadSynonymTranslator(String name) {
        try {
            File file = new File(testMode? "test.test" : "data/"+name+".ser");
            FileInputStream fin = new FileInputStream(file);
            ObjectInputStream oin = new ObjectInputStream(fin);
            SynonymTranslator res = (SynonymTranslator) oin.readObject();
            oin.close();
            fin.close();
            return Objects.requireNonNull(res);
        } catch (Exception e) {
            return new SynonymTranslator();
        }
    }

    public static void saveSynonymTranslator(SynonymTranslator t, String name) {
        try {
            File file = new File(testMode? "test.test" : "data/"+name+".ser");
            FileOutputStream fout = new FileOutputStream(file);
            ObjectOutputStream oout = new ObjectOutputStream(fout);
            oout.writeObject(t);
            oout.close();
            fout.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static Player loadPlayer(String name) {
        try {
            File file = new File(testMode? "test.test" : "data/players/" + name + ".ser");
            FileInputStream fin = new FileInputStream(file);
            ObjectInputStream oin = new ObjectInputStream(fin);
            Player res = (Player) oin.readObject();
            oin.close();
            fin.close();
            return Objects.requireNonNull(res);
        } catch (Exception e) {
            return null;
        }
    }

    public static void savePlayer(String name, Player player) {
        try {
            File file = new File(testMode? "test.test" : "data/players/" + name+".ser");
            FileOutputStream fout = new FileOutputStream(file);
            ObjectOutputStream oout = new ObjectOutputStream(fout);
            oout.writeObject(player);
            oout.close();
            fout.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
